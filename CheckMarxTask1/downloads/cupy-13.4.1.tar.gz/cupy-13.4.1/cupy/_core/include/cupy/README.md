# "include" directory

All files and directories in this directory will be copied to the distribution (sdist and wheel).
Note that items starting with `.` (e.g., `.git`) are excluded.
See `setup.py` for details.

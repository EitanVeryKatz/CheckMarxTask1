Additional Information
======================

.. toctree::
   :maxdepth: 1

   Parquet <dataframe-parquet.rst>
   Indexing <dataframe-indexing.rst>
   SQL <dataframe-sql.rst>
   Join Performance <dataframe-joins.rst>
   Shuffling Performance <dataframe-groupby.rst>
   dataframe-categoricals.rst
   Extend <dataframe-extend.rst>
   Hive Partitioning <dataframe-hive.rst>

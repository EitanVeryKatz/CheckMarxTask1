---
orphan: true
---

# Adding an edit button

```{versionadded} 2022.02.14

```

```{versionchanged} 2024.05.06
View button support was added, which required providing a more general configuration mechanism.
```

This page has been replaced with {doc}`./top-of-page-buttons`.

# Quickstart

```{include} ../README.md
:start-after: <!-- start quickstart -->
:end-before: <!-- end quickstart -->
```

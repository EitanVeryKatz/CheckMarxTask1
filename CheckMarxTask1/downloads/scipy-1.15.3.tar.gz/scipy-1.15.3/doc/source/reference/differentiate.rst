.. automodule:: scipy.differentiate
   :no-members:
   :no-inherited-members:
   :no-special-members:

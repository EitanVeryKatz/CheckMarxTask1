.. _optimize.minimize-trustconstr:

minimize(method='trust-constr')
-------------------------------------------

.. scipy-optimize:function:: scipy.optimize.minimize
   :impl: scipy.optimize._trustregion_constr._minimize_trustregion_constr
   :method: trust-constr

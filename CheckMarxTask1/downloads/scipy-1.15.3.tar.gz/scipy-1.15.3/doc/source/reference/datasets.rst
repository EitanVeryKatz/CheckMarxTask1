.. automodule:: scipy.datasets
   :no-members:
   :no-inherited-members:
   :no-special-members:

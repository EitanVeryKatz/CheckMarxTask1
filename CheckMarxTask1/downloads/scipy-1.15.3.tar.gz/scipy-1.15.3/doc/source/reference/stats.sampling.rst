.. automodule:: scipy.stats.sampling
   :no-members:
   :no-inherited-members:
   :no-special-members:

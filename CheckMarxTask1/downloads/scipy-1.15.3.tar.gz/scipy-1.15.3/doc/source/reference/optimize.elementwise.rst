.. automodule:: scipy.optimize.elementwise
   :no-members:
   :no-inherited-members:
   :no-special-members:

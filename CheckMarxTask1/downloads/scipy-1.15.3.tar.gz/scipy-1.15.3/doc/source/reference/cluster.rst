.. automodule:: scipy.cluster
   :no-members:
   :no-inherited-members:
   :no-special-members:
